﻿public class Student : Person, KPI
{
    private string major;

    public string Major
    {
        get { return major; }
        set { major = value; }
    }

    public override string Name
    {
        get { return base.Name; }
        set
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentException("Name cannot be empty or null.");
            }
            base.Name = value;
        }
    }

    public void kpi()
    {
        Console.WriteLine($"Student {Name} is in the {Major} department.");
    }
}
