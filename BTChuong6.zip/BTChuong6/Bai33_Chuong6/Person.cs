﻿public abstract class Person
{
    public virtual string Name { get; set; }
}
