﻿public interface KPI
{
    void kpi();
}
