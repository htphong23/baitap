﻿public abstract class Person
{
    public string Name { get; set; }
}
